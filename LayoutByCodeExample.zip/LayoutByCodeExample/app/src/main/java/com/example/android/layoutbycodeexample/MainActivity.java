package com.example.android.layoutbycodeexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView tvMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        tvMessage = new TextView(this);
        tvMessage.setText("Hello, Android!");
        tvMessage.setTextAppearance(this, android.R.style.TextAppearance_Large);

        Button button = new Button(this);
        button.setText("Say Hello");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        layout.addView(tvMessage);
        layout.addView(button);

        setContentView(layout);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvMessage.setText("Button Clicked!");
            }
        });
    }
}
