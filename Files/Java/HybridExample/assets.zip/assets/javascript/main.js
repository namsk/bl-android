function messageFromActivity(message) {
    //  Activity로부터 호출되는 함수
    var obj = document.getElementById("activity_message");
    obj.innerText = message;

}

function sendMessageToActivity() {
    //  Activity의 HybridBridge에 구현된 messageFromHtml 메서드를 호출
    var message = document.getElementById("html_message").value;
    window.HybridBridge.messageFromHtml(message);
}