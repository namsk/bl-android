package com.example.android.linearlayoutexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
//        return super.onTouchEvent(event);
        setContentView(R.layout.activity_main);
        return true;
    }

    public void onButton1Clicked(View v) {
        setContentView(R.layout.normal);
    }

    public void onButton2Clicked(View v) {
        setContentView(R.layout.padding);
    }

    public void onButton3Clicked(View v) {
        setContentView(R.layout.gravity);
    }

    public void onButton4Clicked(View v) {
        setContentView(R.layout.weight);
    }

    public void onButton5Clicked(View v) {
        setContentView(R.layout.baseline);
    }

    public void onButton6Clicked(View v) {
        setContentView(R.layout.gravitytext01);
    }

    public void onButton7Clicked(View v) {
        setContentView(R.layout.gravitytext02);
    }

    public void onButton8Clicked(View v) {
        setContentView(R.layout.gravitytext03);
    }

    public void onButton9Clicked(View v) {
        TextView textView = new TextView( this );
        textView.setText( "Hello World" );

        Button button = new Button( this );
        button.setText( "click" );

        LinearLayout layout = new LinearLayout( this );
        layout.setOrientation( LinearLayout.VERTICAL );

        layout.addView( textView );
        layout.addView( button );

        setContentView( layout );
    }
}
