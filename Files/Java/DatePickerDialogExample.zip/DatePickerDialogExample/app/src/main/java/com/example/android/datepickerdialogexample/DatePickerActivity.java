package com.example.android.datepickerdialogexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DatePickerActivity extends AppCompatActivity {
    @Override
    public void onBackPressed() {
        //  TODO: Back 키가 눌렸을 때 취소 결과값을 MainActivity로 돌려보내기
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_picker);

        //  TODO: 레이아웃 내 DatePicker에서 날짜가 선택되었을 때 결과값을 MainActivity로 돌려보내기

    }
}
