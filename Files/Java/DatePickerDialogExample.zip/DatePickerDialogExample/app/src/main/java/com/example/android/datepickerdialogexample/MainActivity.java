package com.example.android.datepickerdialogexample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_DATEPICKER = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.buttonDateActivity)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //  TODO: DatePickerActivity start하기
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //  TODO: DatePickerActivity로부터 넘어온 값을 editText에 출력하기

    }

    public void dialogDatePicker(View view) {
        //  TODO: DatePickerDialog를 띄우고 날짜가 변경되었을 때 editText에 출력하기

    }
}
