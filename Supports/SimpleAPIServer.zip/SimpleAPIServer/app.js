const express = require("express");
const fs = require("fs");
const csv = require("csv-parser");
const app = express();

const DATA_FILE = "./data/sampledata.db.csv";

const db = [];

fs.createReadStream(DATA_FILE)
  .pipe(csv())
  .on("data", (data) => db.push(data))
  .on("end", () => {
    console.log("[Server] Movie Data is loaded");
  });

app.use(express.static("public"));
app.set("views", __dirname + "/views");
app.set("view engine", "ejs");

app.use((req, res, next) => {
  if (req.path.startsWith("/movies")) {
    res.setHeader("Content-Type", "text/json;chsrset=UTF-8");
    res.setHeader("Access-Control-Allow-Origin", "*");
  }
  next();
});

app.get("/", (req, res) => {
  res.render("index");
});

app.get("/movies", (req, res) => {
  res.json({ movies: db });
});

app.get("/movies/:id", (req, res) => {
  res.json({ movie: db.filter((data) => data.id == req.params.id) });
});

app.listen(3000, () => {
  console.log("[Server] Simple API Server is listening on port 3000");
});
